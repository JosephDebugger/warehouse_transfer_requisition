<?php
$conPrefix = '';
include 'includes/session.php';
include 'includes/header.php';
?>
<style>
  .badge {
  padding: 1px 9px 2px;
  font-size: 12.025px;
  font-weight: bold;
  white-space: nowrap;
  color: #ffffff;
  background-color: #999999;
  -webkit-border-radius: 9px;
  -moz-border-radius: 9px;
  border-radius: 9px;
}

.badge:hover {
  color: #ffffff;
  text-decoration: none;
  cursor: pointer;
}

.badge-error {
  background-color: #b94a48;
}

.badge-error:hover {
  background-color: #953b39;
}

.badge-warning {
  background-color: #f89406;
}

.badge-warning:hover {
  background-color: #c67605;
}
.badge-danger {
  background-color:#bb2124;
}



.badge-primary {
  background-color: #0275d8;
}

.badge-primary:hover {
  background-color: #0275d8;
}
.badge-success {
  background-color: #468847;
}

.badge-success:hover {
  background-color: #356635;
}

.badge-info {
  background-color: #3a87ad;
}

.badge-info:hover {
  background-color: #2d6987;
}

.badge-inverse {
  background-color: #333333;
}

.badge-inverse:hover {
  background-color: #1a1a1a;
}
</style>

<body class="hold-transition skin-blue sidebar-mini">
  <link rel="stylesheet" href="dist/css/select2.min.css" />
  <div class="wrapper">

    <?php include 'includes/navbar.php'; ?>
    <?php include 'includes/menubar.php'; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Warehouse Product Transfer
        </h1>
        <ol class="breadcrumb">
          <li><a href="user-home.php"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active">Warehouse Product Transfer </li>
        </ol>

      </section>
      <!-- Main content -->
      <section class="content">
        <link rel="stylesheet" href="css/buttons.dataTables.min.css" />
        <div class="row">
          <div class="col-xs-12">
            <div class="box container ">
              <div class="box-header with-border">
                <div class="col-xs-6">
                  <div id='divMsg' class='alert alert-success alert-dismissible successMessage'></div>
                  <div id='divErrorMsg' class='alert alert-danger alert-dismissible errorMessage'></div>
                </div>

              </div>
              <div class="col-12 row d-flex">

                <div class="col-md-4">
                  <label for="requisitions" class="col-md-4">Transfer Date :</label>
                  <div class="input-group col-md-8">
                    <input class="form-control col-md-12" type="Date" name="requisition_transfer_date" id="requisition_transfer_date" value="<?=  date('Y-m-d') ?>" disabled>
                  </div>
                </div>
                <div class="col-md-4">
                  <label for="warehouse" class="col-md-4">Select Warehouse :</label>
                  <div class="input-group col-md-8">
                    <select class="form-control  col-md-12" name="warehouse" id="warehouse" onchange="getRequisition()">
                      <option value="" selected>~~ Select Warehouse ~~</option>
                      <?php
                      /*$sql = "SELECT id, wareHouseName
                                FROM tbl_warehouse
                                WHERE deleted='No' AND status='Active' 
                                ORDER BY id ASC";*/
                      $sql = "SELECT DISTINCT tbl_warehouse.id, tbl_warehouse.wareHouseName  
                              FROM `tbl_warehouse_transfer_requisition_details`
                              INNER JOIN tbl_warehouse_transfer_requisition ON tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id = tbl_warehouse_transfer_requisition.id
                              INNER JOIN tbl_warehouse ON tbl_warehouse_transfer_requisition_details.from_warehouse = tbl_warehouse.id
                              WHERE tbl_warehouse_transfer_requisition_details.status='Active' AND (tbl_warehouse_transfer_requisition_details.requisition_status='pending' OR tbl_warehouse_transfer_requisition_details.requisition_status='transit') 
                                    AND (tbl_warehouse_transfer_requisition.transfer_by = '".$loginID."')
                              ORDER BY `id` DESC";
                      $res = $conn->query($sql);
                      while ($row = $res->fetch_assoc()) {
                        echo '<option value="' . $row['id'] . '">' . $row['wareHouseName'] . '</option>';
                      }
                      ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="box-body table-responsive">
                <table id="manageRequisitionProductsTable" class="table table-bordered" style="width:100%">
                  <thead>
                    <th>#SN</th>
                    <th>Product Information</th>
                    <th>Requisition Quantity</th>
                    <th>Requisition Date</th>
                    <th>Transfer Quantity</th>
                    <th>Status</th>
                    <th style="width:8%;">Action</th>
                  </thead>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <?php include 'includes/footer.php'; ?>
  </div>
  <?php
  include 'includes/scripts.php';
 
  ?>
  <script src="dist/js/select2.min.js"></script>
  <script src="includes/js/manageWarehouseProductTransfer.js"></script>
</body>

</html>