<?php
$conPrefix = '../';
include $conPrefix . 'includes/session.php';

date_default_timezone_set('Asia/Dhaka');
//$toDay = (new DateTime())->format("Y-m-d");
$loginID = $_SESSION['user'];

if (isset($_GET['getRequisition'])) {
    $wareHouse = $_GET['wareHouse'];

    $sql = "SELECT tbl_warehouse_transfer_requisition_details.id, tbl_warehouse_transfer_requisition_details.request_date, tbl_warehouse_transfer_requisition.requisition_no , tbl_units.unitName as units, tbl_warehouse_transfer_requisition.id as requisition_id, tbl_warehouse_transfer_requisition_details.transfer_quentity , tbl_warehouse_transfer_requisition_details.from_warehouse_current_stock,tbl_warehouse_transfer_requisition_details.send_quantity, tbl_warehouse_transfer_requisition_details.requisition_status, tbl_products.id p_id, tbl_products.productName as productName, tbl_products.modelNo,  tbl_products.productDescriptions,tbl_products.type, w1.wareHouseName wr1,w1.id w1_id, w2.wareHouseName wr2, w2.id w2_id
            FROM tbl_warehouse_transfer_requisition_details
            INNER JOIN tbl_products ON tbl_products.id = tbl_warehouse_transfer_requisition_details.product_id
            JOIN tbl_warehouse_transfer_requisition ON tbl_warehouse_transfer_requisition.id = tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id
            INNER JOIN tbl_warehouse as w1 ON w1.id = tbl_warehouse_transfer_requisition_details.from_warehouse 
            INNER JOIN tbl_warehouse as w2 ON w2.id = tbl_warehouse_transfer_requisition_details.to_warehouse 
            INNER JOIN tbl_units ON tbl_products.units = tbl_units.id AND tbl_units.deleted = 'no'
            WHERE tbl_warehouse_transfer_requisition_details.deleted = 'No' AND tbl_warehouse_transfer_requisition_details.status = 'Active' AND tbl_warehouse_transfer_requisition_details.requisition_status = 'transit'  AND tbl_warehouse_transfer_requisition_details.to_warehouse  = '$wareHouse'  
            order by tbl_warehouse_transfer_requisition_details.id desc";

    $result = $conn->query($sql);
    $data = array();
    $i = 0;

    while ($row = $result->fetch_array()) {
        $data[$i] = $row;
        $i++;
    }
    echo json_encode([
        'requisition_code' => $wareHouse,
        'success'       => 'success',
        'data'          => $data,
    ]);
} else if (isset($_POST['receiveProduct'])) {
    $status = '';
    $product_faild_ids = [];
    $rowOrders = [];
    for ($i = 0; $i < Count($_POST['receiveQuantity']); $i++) {
        $products = $_POST['productId'][$i];
        $product_type = $_POST['product_type'][$i];
        $requisitionId = $_POST['requisitionId'][$i];
        $requisitProductId = $_POST['requisitionProductId'][$i];
        $wareHouseFrom = $_POST['wareHouseFrom'][$i];
        $wareHouseTo = $_POST['wareHouseTo'][$i];
        $receiveStock = $_POST['receiveQuantity'][$i];
        $transferedQuantity = $_POST['transferedQuantity'][$i];
        $fromWarehouse_CurrentStock = $_POST['fromWarehouse_CurrentStock'][$i];
        $updatedQty = '';
        $rowOrder = $_POST['rowOrder'][$i];

        if ($receiveStock == $transferedQuantity) {
            $Matched = "Yes";
            $notMatchedQty = "0";
        } else {
            $Matched = "No";
        }
        $notMatchedQty = $transferedQuantity - $receiveStock;
        $updatedQty = $transferedQuantity - $receiveStock;

        if ($updatedQty < 0) {
            $sql = "SELECT currentStock FROM `tbl_currentStock` where tbl_wareHouseId = $wareHouseFrom  AND deleted='No' AND tbl_productsId = $products ";
            $result = $conn->query($sql);
            $data = $result->fetch_assoc();
            $availableStock =  $data['currentStock'];
            if (abs($updatedQty) > $availableStock) {
                array_push($rowOrders, $rowOrder);
            } else {

                $sql = "UPDATE tbl_warehouse_transfer_requisition_details set `receive_date`= '$toDay', `receive_quantity` = '$receiveStock', `receive_by` =  '$loginID' , `requisition_status` = 'completed', `matched` = '$Matched', `not_mached_qty` = '$notMatchedQty'
                WHERE tbl_warehouse_transfer_requisition_details.id =  '$requisitProductId'";
                $result = $conn->query($sql);
                $rowCounter1 = [];
                $rowCounter2 = [];
                $sql = "SELECT id  from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId' AND requisition_status NOT IN('cancel','adjusted') and deleted ='No' AND  `status` = 'Active'";
                $result = $conn->query($sql);

                while ($row1 = $result->fetch_array()) {
                    array_push($rowCounter1, $row1['id']);
                }

                $sql = "SELECT id from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId'  and requisition_status ='completed' and deleted ='No' AND  `status` = 'Active'";
                $result = $conn->query($sql);

                while ($row1 = $result->fetch_array()) {
                    array_push($rowCounter2, $row1['id']);
                }

                if (count($rowCounter1) == count($rowCounter2)) {
                    $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Complete'
                WHERE tbl_warehouse_transfer_requisition.id =  '$requisitionId'  AND `deleted` = 'No' AND  `status` = 'Active'";

                    $result = $conn->query($sql);
                } else if (count($rowCounter1) > count($rowCounter2)) {
                    $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Incomplete'
                WHERE tbl_warehouse_transfer_requisition.id =   '$requisitionId' AND `deleted` = 'No' AND  `status` = 'Active'";

                    $result = $conn->query($sql);
                }
                $status  = 'success';
            }
        } else {
            $sql = "UPDATE tbl_warehouse_transfer_requisition_details set `receive_date`= '$toDay', `receive_quantity` = '$receiveStock', `receive_by` =  '$loginID' , `requisition_status` = 'completed', `matched` = '$Matched', `not_mached_qty` = '$notMatchedQty'
            WHERE tbl_warehouse_transfer_requisition_details.id =  '$requisitProductId'";
            $result = $conn->query($sql);
            $rowCounter1 = [];
            $rowCounter2 = [];
            $sql = "SELECT id  from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId' AND requisition_status NOT IN('cancel','adjusted') and deleted ='No' AND  `status` = 'Active'";
            $result = $conn->query($sql);

            while ($row1 = $result->fetch_array()) {
                array_push($rowCounter1, $row1['id']);
            }

            $sql = "SELECT id from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId'  and requisition_status ='completed' and deleted ='No' AND  `status` = 'Active'";
            $result = $conn->query($sql);

            while ($row1 = $result->fetch_array()) {
                array_push($rowCounter2, $row1['id']);
            }

            if (count($rowCounter1) == count($rowCounter2)) {
                $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Complete'
            WHERE tbl_warehouse_transfer_requisition.id =  '$requisitionId'  AND `deleted` = 'No' AND  `status` = 'Active'";

                $result = $conn->query($sql);
            } else if (count($rowCounter1) > count($rowCounter2)) {
                $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Incomplete'
            WHERE tbl_warehouse_transfer_requisition.id =   '$requisitionId' AND `deleted` = 'No' AND  `status` = 'Active'";

                $result = $conn->query($sql);
            }
            $status  = 'success';
        }

    
            //     if ($updatedQty <= $availableStock) {
            //         $sql = "INSERT INTO tbl_warehouse_transfer(warehouse_requisition_transfer_product_id, transferDate, tbl_products_id, tbl_current_warehouse_id, current_stock, tbl_transfer_warehouse_id, transfer_stock, entryBy, entryDate) 
            //         VALUES ('$requisitProductId','$toDay','$products','$wareHouseTo','$fromWarehouse_CurrentStock','$wareHouseFrom','$updatedQty','$loginID','$toDay')";
            //         if ($result = $conn->query($sql)) {
            //             $sql = "UPDATE tbl_currentStock 
            //         SET transferTo= transferTo + $updatedQty, lastUpdatedDate='$toDay', lastUpdatedBy='$loginID', 
            //             currentStock = currentStock + $updatedQty 
            //         WHERE tbl_wareHouseId='$wareHouseFrom' AND tbl_productsId='$products' AND deleted='No'";
            //             if ($conn->query($sql)) {
            //                 $sql = "UPDATE tbl_currentStock 
            //             SET transferFrom= transferFrom + $updatedQty, lastUpdatedDate='$toDay', lastUpdatedBy='$loginID',
            //                 currentStock = currentStock - $updatedQty 
            //             WHERE tbl_wareHouseId='$wareHouseTo' AND tbl_productsId='$products' AND deleted='No'";
            //                 if ($conn->query($sql)) {
            //                     if ($conn->affected_rows == 0) {
            //                         $sql = "INSERT INTO tbl_currentStock(tbl_productsId, tbl_wareHouseId, currentStock, transferTo, entryBy,entryDate) 
            //                     VALUES ('$products', '$wareHouseTo', '$updatedQty', '$updatedQty', '$loginID', '$toDay')";
            //                         $conn->query($sql);
            //                     }
            //                 } else {
            //                     echo json_encode($conn->error . $sql);
            //                 }
            //             } else {
            //                 echo json_encode($conn->error . $sql);
            //             }
            //         } else {
            //             echo json_encode([
            //                 'error'       => 'error'
            //             ]);
            //         }
            //     } else {
            //         return json_encode([
            //             'not_available'  => 'not_available'
            //         ]);
            //     }
            // } else {
            //     $sql = "SELECT currentStock FROM `tbl_currentStock` where tbl_wareHouseId = $wareHouseFrom  AND deleted='No' AND tbl_productsId = $products ";
            //     $result = $conn->query($sql);
            //     $data = $result->fetch_assoc();
            //     $absQty = abs($updatedQty);
            //     $availableStock =  $data['currentStock'];
            //     if ($absQty <= $availableStock) {
            //         $sql = "INSERT INTO tbl_warehouse_transfer(warehouse_requisition_transfer_product_id, transferDate, tbl_products_id, tbl_current_warehouse_id, current_stock, tbl_transfer_warehouse_id, transfer_stock, entryBy, entryDate) 
            //                 VALUES ('$requisitProductId','$toDay','$products','$wareHouseFrom','$fromWarehouse_CurrentStock','$wareHouseTo','$updatedQty','$loginID','$toDay')";
            //         if ($result = $conn->query($sql)) {
            //             $sql = "UPDATE tbl_currentStock 
            //                 SET transferFrom= transferFrom + $absQty, lastUpdatedDate='$toDay', lastUpdatedBy='$loginID', 
            //                     currentStock = currentStock + $updatedQty 
            //                 WHERE tbl_wareHouseId='$wareHouseFrom' AND tbl_productsId='$products' AND deleted='No'";
            //             if ($conn->query($sql)) {
            //                 $sql = "UPDATE tbl_currentStock 
            //                     SET transferTo= transferTo + $absQty, lastUpdatedDate='$toDay', lastUpdatedBy='$loginID',
            //                         currentStock = currentStock - $updatedQty 
            //                     WHERE tbl_wareHouseId='$wareHouseTo' AND tbl_productsId='$products' AND deleted='No'";
            //                 if ($conn->query($sql)) {
            //                     if ($conn->affected_rows == 0) {
            //                         $sql = "INSERT INTO tbl_currentStock(tbl_productsId, tbl_wareHouseId, currentStock, transferTo, entryBy,entryDate) 
            //                             VALUES ('$products', '$wareHouseTo', '$updatedQty', '$updatedQty', '$loginID', '$toDay')";
            //                         $conn->query($sql);
            //                     }
            //                 } else {
            //                     echo json_encode($conn->error . $sql);
            //                 }
            //             } else {
            //                 echo json_encode($conn->error . $sql);
            //             }
            //         } else {
            //             echo json_encode([
            //                 'error'       => 'error'
            //             ]);
            //         }
            //     } else {
            //         return json_encode([
            //             'not_available'  => 'not_available'
            //         ]);
            //     }
            // }
            // // $sql = "UPDATE tbl_warehouse_transfer set transfer_stock = transfer_stock - $updatedQty, entryBy = '$loginID', entryDate = '$toDay' where warehouse_requisition_transfer_product_id =$requisitProductId";
            // // $conn->query($sql);

      
    }

    if ($status == 'success') {
        echo json_encode([
            'success'     =>  $status,
            'rowOrder' => $rowOrders
        ]);
    } else {
        echo json_encode([
            'error'     => 'error',
            'rowOrder' => $rowOrders
        ]);
    }
}
