<?php
$conPrefix = '../';
include $conPrefix . 'includes/session.php';

date_default_timezone_set('Asia/Dhaka');
//$toDay = (new DateTime($test))->format("Y-m-d H:i:s");
$toDay = (new DateTime())->format("Y-m-d");

if (isset($_POST['action'])) {
    if ($_POST['action'] == "fetch_current_balance") {
        $bankInfoId       =  $_POST['bankInfoId'];
        $paymentMethodId  =  $_POST['paymentMethodId'];
        if($paymentMethodId == "3" || $paymentMethodId == "4"){
            if($bankInfoId != ""){
                $sql = "SELECT current_balance FROM `tbl_bank_account_info` WHERE id = $bankInfoId";
            }else{
                return '';
            }
        }else{
            $sql = "SELECT current_balance FROM `tbl_paymentMethod` WHERE id = $paymentMethodId";
        }
        $result = $conn->query($sql);
        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            $currentBalance = $row["current_balance"];
         }else{
            $currentBalance = 0;
         }
        echo $currentBalance;
    } else if ($_POST['action'] == "saveTransfer") {
        $loginID             =   $_SESSION['user'];
        $transfer_date       =   $_POST['transfer_date'];
        $transfer_by         =   $conn->real_escape_string($loginID);
        $from_method_id      =   $conn->real_escape_string($_POST['from_method_id']);
        $from_bank_id        =   $conn->real_escape_string($_POST['from_bank_id']);
        $from_method_name    =   $conn->real_escape_string($_POST['from_method_name']);
        $from_bank_info      =   $conn->real_escape_string($_POST['from_bank_info']);
        $from_currentAmount  =   $conn->real_escape_string($_POST['from_currentAmount']);
        $transferAmount      =   $conn->real_escape_string($_POST['from_transferAmount']);
        $from_afterTransfer  =   $conn->real_escape_string($_POST['from_afterTransfer']);
        $to_method_id        =   $conn->real_escape_string($_POST['to_method_id']);
        $to_bank_id          =   $conn->real_escape_string($_POST['to_bank_id']);
        $to_method_Name      =   $conn->real_escape_string($_POST['to_method_name']);
        $to_bank_info        =   $conn->real_escape_string($_POST['to_bank_info']);
        $to_currentAmount    =   $conn->real_escape_string($_POST['to_currentAmount']);
        $to_afterTransfer    =   $conn->real_escape_string($_POST['to_afterTransfer']);
  
        if($from_bank_id ==''){  $from_bank_id =0; }
        if($to_bank_id =='')  {  $to_bank_id =0; }

        if($from_bank_info =='~~ Select Bank ~~'){ $from_bank_info =NULL; }
        if($to_bank_info =='~~ Select Bank ~~'){   $to_bank_info =NULL; }

        if(is_nan($transferAmount)){  $transferAmount =0; }
        $i=0;

        try {
            $conn->begin_transaction();
            $sql = "INSERT INTO `tbl_amount_transfer` 
                                        (transfer_date, 
                                         transfer_by, 
                                         from_payment_method_id, 
                                         from_bank_info_id, 
                                         from_method_name,
                                         from_bank_info,
                                         from_current_amount,
                                         from_after_transfer,  
                                         transfer_amount, 
                                         to_payment_method_id,
                                         to_bank_info_id,
                                         to_method_name,
                                         to_bank_info,
                                         to_current_amount,
                                         to_after_transfer,
                                         created_by,
                                         created_date) 
                                   VALUES 
                                       ('$transfer_date',
                                         $transfer_by,
                                         $from_method_id ,
                                         $from_bank_id ,
                                        '$from_method_name' ,
                                        '$from_bank_info' ,
                                         $from_currentAmount,
                                         $from_afterTransfer,
                                         $transferAmount,
                                         $to_method_id, 
                                         $to_bank_id, 
                                        '$to_method_Name',
                                        '$to_bank_info',
                                         $to_currentAmount,
                                         $to_afterTransfer,
                                         $loginID,
                                         $toDay)";
           
            if ($conn->query($sql)) {
               
                if($transferAmount > 0){
                    if($from_bank_id ==''){
                        $sql2="UPDATE `tbl_paymentMethod` SET current_balance = current_balance - $transferAmount WHERE id = '$from_method_id'";
                        $conn->query($sql2);
                        $i++;
                    }else{
                        $sql2="UPDATE `tbl_bank_account_info` SET current_balance = current_balance - $transferAmount WHERE id = '$from_bank_id'";
                        $conn->query($sql2);
                        $sql3="UPDATE `tbl_paymentMethod` SET current_balance = current_balance - $transferAmount WHERE id = '$from_method_id'";
                        $conn->query($sql3);
                        $i++;
                    }
                    if($to_bank_id ==''){
                        $sql2="UPDATE `tbl_paymentMethod` SET current_balance = current_balance + $transferAmount WHERE id = '$to_method_id'";
                        $conn->query($sql2);
                        $i++;
                    }else{
                        $sql2="UPDATE `tbl_bank_account_info` SET current_balance = current_balance + $transferAmount WHERE id = '$to_bank_id'";
                        $conn->query($sql2);
                        $sql3="UPDATE `tbl_paymentMethod` SET current_balance = current_balance + $transferAmount WHERE id = '$to_method_id'";
                        $conn->query($sql3);
                        $i++;
                    }
                }
                if($i==2){
                    $conn->commit();
                    echo json_encode('Success');
                }
              
            } else {
                $conn->rollBack();
                echo json_encode($conn->error.$sql);
            }
        } catch (Exception $e) {
            $conn->rollBack();
            echo json_encode('RollBack');
        }
        $conn->close();

    } else if ($_POST['action'] == "deleteTransfer") {
        $loginID = $_SESSION['user'];
        $id      = $_POST['id'];
        try {
            $conn->begin_transaction();
            $sql = "SELECT  transfer_amount, from_bank_info_id, to_bank_info_id, from_payment_method_id, to_payment_method_id
                    FROM tbl_amount_transfer
                    WHERE id='$id' and deleted='No'";
            $result              = $conn->query($sql);
            $row                 = $result->fetch_assoc();
            $transfer_amount     = $row['transfer_amount'];
            $from_bank_id        = $row['from_bank_info_id'];
            $to_bank_id          = $row['to_bank_info_id'];
            $from_method_id      = $row['from_payment_method_id'];
            $to_method_id        = $row['to_payment_method_id'];
            
                $i=0;
                if($transfer_amount > 0){
                    if($from_bank_id > 0){
                        $sql="UPDATE `tbl_paymentMethod` SET current_balance = current_balance + $transfer_amount WHERE id = '$from_method_id'";
                        $conn->query($sql);
                        $sql2="UPDATE `tbl_bank_account_info` SET current_balance = current_balance + $transfer_amount WHERE id = '$from_bank_id'";
                        $conn->query($sql2);
                        $i++;
                    }else{
                        $sql3="UPDATE `tbl_paymentMethod` SET current_balance = current_balance + $transfer_amount WHERE id = '$from_method_id'";
                        $conn->query($sql3);
                        $i++;
                    }
                    if($to_bank_id > 0){
                        $sql4="UPDATE `tbl_paymentMethod` SET current_balance = current_balance - $transfer_amount WHERE id = '$to_method_id'";
                        $conn->query($sql4);
                        $sql5="UPDATE `tbl_bank_account_info` SET current_balance = current_balance - $transfer_amount WHERE id = '$to_bank_id'";
                        $conn->query($sql5);
                        $i++;
                    }else{
                        $sql6="UPDATE `tbl_paymentMethod` SET current_balance = current_balance - $transfer_amount WHERE id = '$to_method_id'";
                        $conn->query($sql6);
                        $i++;
                    }
                }
                if($i==2){
                    $sql = "UPDATE tbl_amount_transfer 
                    SET deleted= 'Yes' , deleted_by='$loginID', deleted_date='$toDay'
                    WHERE id='$id' AND deleted='No'";
                    if ($conn->query($sql)) {
                    $conn->commit();
                    echo 'Success';
                    }
                    else {
                        $conn->rollBack();
                        echo $conn->error . $sql;
                    }
                }
            
        } catch (Exception $e) {
            $conn->rollBack();
            echo 'RollBack';
        }
        $conn->close();
    }
} else {
    $sql = "SELECT tbl_amount_transfer.id as tId, tbl_amount_transfer.transfer_date, tbl_amount_transfer.from_method_name , tbl_amount_transfer.from_bank_info,tbl_bank_account_info.bankName,tbl_bank_account_info.branchName , tbl_amount_transfer.to_bank_info, tbl_amount_transfer.transfer_amount, 
            tbl_amount_transfer.to_method_name  , tbl_amount_transfer.to_after_transfer, tbl_users.fname
            FROM tbl_amount_transfer
            LEFT OUTER JOIN tbl_users ON tbl_amount_transfer.transfer_by = 	tbl_users.id 
            LEFT OUTER JOIN tbl_bank_account_info ON tbl_bank_account_info.id=tbl_amount_transfer.to_bank_info_id
            WHERE tbl_amount_transfer.deleted='No'
            order by tbl_amount_transfer.id DESC";

    $result = $conn->query($sql);
    $i = 1;
    $output = array('data' => array());
    while ($row = $result->fetch_array()) {
        $transferId = $row['tId'];
        if( $row['from_bank_info'] == ''){
            $to_bank_info="";
        }else{
            $to_bank_info="<strong>Bank Info - </strong>". $row['from_bank_info'];
        }
        if( $row['to_bank_info'] == ''){
            $rcv_bank_info="";
        }else{
            $rcv_bank_info="<strong>Bank Info - </strong>". $row['to_bank_info']." - ".$row['bankName']." - ".$row['branchName'];
        }

        $button = '<a href="#" onclick="deleteTransfer(' . $transferId . ')"><button class="btn btn-warning btn-sm btn-flat"><i class="fa fa-edit"></i> Discard Transfer</button></a>';
        $output['data'][] = array(
            $i++,
            $row['transfer_date'],
            $row['fname'],
           '<strong>Method Name - </strong>'.$row['from_method_name'] . ' <br> ' .  $to_bank_info,
           '<strong>Method Name - </strong>'.$row['to_method_name'] . ' <br> ' .  $rcv_bank_info,
            $row['transfer_amount'],
            $button
        );
    } // /while 
    echo json_encode($output);
}
