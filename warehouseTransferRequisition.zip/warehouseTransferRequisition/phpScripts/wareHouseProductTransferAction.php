<?php
$conPrefix = '../';
include $conPrefix . 'includes/session.php';

date_default_timezone_set('Asia/Dhaka');
//$toDay = (new DateTime())->format("Y-m-d");
$loginID = $_SESSION['user'];

if (isset($_GET['getRequisition'])) {
    $wareHouse = $_GET['wareHouse'];

    $sql = "SELECT tbl_warehouse_transfer_requisition_details.id, tbl_warehouse_transfer_requisition_details.request_date, tbl_warehouse_transfer_requisition.requisition_no, 
                    tbl_warehouse_transfer_requisition_details.from_warehouse_current_stock, tbl_warehouse_transfer_requisition_details.transfer_quentity, tbl_warehouse_transfer_requisition_details.requisition_status,
                    tbl_warehouse_transfer_requisition_details.tbl_serialize_productsIds, tbl_warehouse_transfer_requisition_details.stockQuantities, tbl_products.id p_id, tbl_products.productName as productName, 
                    tbl_products.modelNo, tbl_units.unitName as units , tbl_products.productDescriptions,tbl_products.type, w1.wareHouseName wr1,w1.id w1_id, w2.wareHouseName wr2, w2.id w2_id, tbl_warehouse_transfer_requisition_details.send_quantity
            FROM tbl_warehouse_transfer_requisition_details
            INNER JOIN tbl_products ON tbl_products.id = tbl_warehouse_transfer_requisition_details.product_id AND tbl_products.deleted = 'No'  AND tbl_products.status = 'Active'
            INNER JOIN tbl_warehouse_transfer_requisition ON tbl_warehouse_transfer_requisition.id = tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id AND tbl_warehouse_transfer_requisition.status = 'Active' AND tbl_warehouse_transfer_requisition.deleted = 'No'
            INNER JOIN tbl_warehouse as w1 ON w1.id = tbl_warehouse_transfer_requisition_details.from_warehouse  AND w1.deleted = 'No'
            INNER JOIN tbl_warehouse as w2 ON w2.id = tbl_warehouse_transfer_requisition_details.to_warehouse  AND w2.deleted = 'No'
            INNER JOIN tbl_units ON tbl_products.units = tbl_units.id AND tbl_units.deleted = 'no'
            WHERE tbl_warehouse_transfer_requisition_details.deleted = 'No' AND tbl_warehouse_transfer_requisition_details.status = 'Active'  AND tbl_warehouse_transfer_requisition_details.from_warehouse  = '$wareHouse'  AND tbl_warehouse_transfer_requisition.transfer_by  = '$loginID' AND  tbl_warehouse_transfer_requisition_details.requisition_status NOT IN ('completed','cancel','adjusted') 
            order by tbl_warehouse_transfer_requisition_details.id desc";

    $result = $conn->query($sql);
    $data = array();
    $i = 0;

    while ($row = $result->fetch_array()) {
        $data[$i] = $row;
        $i++;
    }

    echo json_encode([
        'requisition_code' => $wareHouse,
        'success'       => 'success',
        'data'          => $data,
    ]);
} else if (isset($_POST['sentProduct'])) {
     $status ='';
     $product_faild_ids = [];
     $rowOrders = [];
    for ($i = 0; $i < count($_POST['sendQuantity']); $i++) {
        $products = $_POST['productId'][$i];
        $product_type = $_POST['product_type'][$i];
        $transferDate = $_POST['transferDate'][$i];
        $requisitProductId = $_POST['requisitionProductId'][$i];
        $wareHouseFrom = $_POST['wareHouseFrom'][$i];
        $wareHouseTo = $_POST['wareHouseTo'][$i];
        $fromWarehouse_CurrentStock = $_POST['fromWarehouse_CurrentStock'][$i];
        $transferStock = $_POST['sendQuantity'][$i];
        $requisitionQuantity = $_POST['requisitionQuantity'][$i];
        $rowOrder = $_POST['rowOrder'][$i];

        if ($product_type == "serialize") {
            $stockQuantities = $_POST['stockQuantities'][$i];
            $stockQuantityArray = explode(",", $stockQuantities);
            $TemptblSerializeProductsIdArray = $_POST['tbl_serialize_productsIds'][$i];
            $tbl_serialize_productsIdsArray = explode(",", $TemptblSerializeProductsIdArray);
        }

        $sql = "SELECT currentStock FROM `tbl_currentStock` where tbl_wareHouseId =  $wareHouseFrom  AND deleted='No' AND tbl_productsId = $products ";
        $result = $conn->query($sql);
        $data = $result->fetch_assoc();
        $availableStock =  $data['currentStock'];
        if ($transferStock <= $availableStock) {
            $sql = "UPDATE tbl_warehouse_transfer_requisition_details set requisition_transfer_date= '$toDay', send_quantity = $transferStock, requisition_transfer_by =  $loginID, requisition_status = 'transit'
            WHERE tbl_warehouse_transfer_requisition_details.id =  $requisitProductId ";
            $result = $conn->query($sql);
            $warehouseTransferProductId = $conn->insert_id;

            $sql = "INSERT INTO tbl_warehouse_transfer(warehouse_requisition_transfer_product_id, transferDate, tbl_products_id, tbl_current_warehouse_id, current_stock, tbl_transfer_warehouse_id, transfer_stock, entryBy, entryDate) 
            VALUES ('$requisitProductId','$toDay','$products','$wareHouseFrom','$fromWarehouse_CurrentStock','$wareHouseTo','$transferStock','$loginID','$toDay')";
            if ($result = $conn->query($sql)) {

                $sql = "UPDATE tbl_currentStock 
                        SET transferFrom=transferFrom+$transferStock,lastUpdatedDate='$toDay',lastUpdatedBy='$loginID', 
                            currentStock = currentStock - $transferStock 
                        WHERE tbl_wareHouseId='$wareHouseFrom' AND tbl_productsId='$products' AND deleted='No'";
                if ($conn->query($sql)) {
                    $sql = "UPDATE tbl_currentStock 
                            SET transferTo=transferTo+$transferStock,lastUpdatedDate='$toDay',lastUpdatedBy='$loginID',
                                currentStock = currentStock + $transferStock 
                            WHERE tbl_wareHouseId='$wareHouseTo' AND tbl_productsId='$products' AND deleted='No'";
                    if ($conn->query($sql)) {
                        if ($conn->affected_rows == 0) {
                            $sql = "INSERT INTO tbl_currentStock(tbl_productsId, tbl_wareHouseId, currentStock, transferTo, entryBy,entryDate) 
                                    VALUES ('$products', '$wareHouseTo', '$transferStock', '$transferStock', '$loginID','$toDay')";
                            $conn->query($sql);
                        }
                        //====================== Start Serialize Product ======================//
                        if ($product_type == "serialize" && $transferStock > 0) {
                            $maxNumber = '';
                            foreach ($tbl_serialize_productsIdsArray as $key => $tbl_serialize_productsId) {
                                $transferQty = $stockQuantityArray[$key];
                                if ($key == 0) {
                                    // Generate Serial Number
                                    $sql_serializeProduct = "select max(serial_no) as serial from tbl_serialize_products where tbl_productsId='$tbl_serialize_productsId'";
                                    $query_serializeProduct = $conn->query($sql_serializeProduct);
                                    $row_serializeProduct = $query_serializeProduct->fetch_assoc();
                                    $maxNumber = $row_serializeProduct['serial'];
                                    // End
                                }
                                if ($transferQty > 0 && $tbl_serialize_productsId > 0) {
                                    $update_serialize = "UPDATE tbl_serialize_products set used_quantity=used_quantity+$transferQty where id='$tbl_serialize_productsId'";
                                    $updateResult = $conn->query($update_serialize);
                                    // Transfer to New Warehouse
                                    $sql_insert_serialize = "INSERT INTO `tbl_serialize_products`(`tbl_productsId`, `warehouse_id`, `serial_no`, `quantity`, `created_by`, `created_date`) 
                                                  VALUES ('$products','$wareHouseTo','$maxNumber','$transferQty','$loginID','$toDay')";
                                    $insertResult = $conn->query($sql_insert_serialize);
                                    // End
                                    // Start
                                    if ($insertResult) {
                                        $serializeProductId = $conn->insert_id;
                                        $returnSql = "INSERT INTO tbl_sale_serialize_products_return (tbl_name, tbl_id, tbl_serialize_products_id, return_info, returned_quantity, salesType, created_by, created_date) 
                                                              values ('tbl_warehouse_transfer','$warehouseTransferProductId','$tbl_serialize_productsId','$serializeProductId','$transferQty','WarehouseTransfer','$loginID','$toDay')";
                                        $result = $conn->query($returnSql);
                                    }
                                    // End
                                }
                            }
                        }
                        //====================== End Serialize Product ======================//

                   
                        $status  = 'success';
                        
                    } else {

                        echo json_encode($conn->error . $sql);
                    }
                } else {

                    echo json_encode($conn->error . $sql);
                }
            } else {
                echo json_encode([
                    'error'       => 'error',
                ]);
            }
        } else {    
            array_push($rowOrders, $rowOrder);
        }
    }
    if($status == 'success'){
        echo json_encode([
            'success'     =>  $status,
            // 'failed_products' => $product_faild_ids,
            'rowOrder' => $rowOrders
        ]);
    }else{
        echo json_encode([
            'error'     => 'error',
            // 'failed_products' => $product_faild_ids,
            'rowOrder' => $rowOrders
        ]);
    }
   
}
