<?php
$conPrefix = '../';
include $conPrefix . 'includes/session.php';

date_default_timezone_set('Asia/Dhaka');
//$toDay = (new DateTime())->format("Y-m-d");
$loginID = $_SESSION['user'];
/*
   * Load warehouse wise product 
   * load current stock of products
*/
if (isset($_POST['action'])) {

    $requisition_date = $_POST['requisition_date'];
    $transferWareHouse = $_POST['transferWareHouse'];
    $transfer_by = $_POST['transfer_by'];
    $requisition_code = '';

    $sql = "SELECT  LPAD(IFNULL(max(requisition_no),0)+1, 6, 0) as requisition_no FROM `tbl_warehouse_transfer_requisition`";
    $result = $conn->query($sql);

    if ($prow = $result->fetch_assoc()) {
        $requisition_code = $prow['requisition_no'];
    }
    if ($requisition_code == "") {
        $requisition_code = "000001";
    }

    $sql = "INSERT into `tbl_warehouse_transfer_requisition` ( `requisition_date`, `requisition_no`, `transfer_by`,`receive_warehouse`, `status`, `deleted`,`created_by`, `created_date`, `created_at`) 
            VALUES ('$requisition_date','$requisition_code', '$transfer_by','$transferWareHouse','Inactive','No','$loginID','$toDay','$toDay')";
    $result = $conn->query($sql);
    $id = $conn->insert_id;
    echo json_encode([
        'success'          => 'success',
        'id'               => $id,
        'requisition_code' => $requisition_code,
        'requisition_date' => $requisition_date
    ]);
} else if (isset($_GET['getToWareHouse'])) {

    $fromWarehouseId = $_GET['fromWarehouseId'];
    $sql = "SELECT id, wareHouseName
    FROM tbl_warehouse
    WHERE   id != '$fromWarehouseId' AND deleted='No' AND status='Active' 
    ORDER BY id ASC";

    $result = $conn->query($sql);
    $data = [];
    $i = 0;
    while ($row = $result->fetch_array()) {
        $data[$i] = $row;
        $i++;
    }
    echo json_encode([
        'success'       => 'success',
        'data'          => $data
    ]);
} else if (isset($_POST['toWareHouse'])) {

    $to_warehouse_id = $_POST['to_warehouse_id'];
    $productsId = $_POST['productsId'];

    $sql = "SELECT tbl_currentStock.id, tbl_currentStock.currentStock
            FROM tbl_currentStock
            WHERE tbl_currentStock.tbl_productsId='$productsId' AND tbl_currentStock.tbl_wareHouseId =  $to_warehouse_id AND tbl_currentStock.deleted='No'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $currentStock = $row['currentStock'];
    echo $currentStock;
} else if (isset($_POST['saveRequisition'])) {

    $requisition_id = $_POST['requisition_id'];
    $product = $_POST['product'];
    $wareHouseID = $_POST['wareHouseID'];
    $transferStock = $_POST['transferStock'];
    $transferWareHouse = $_POST['transferWareHouse'];
    $requisition_date = $_POST['requisition_date'];
    $fromWarehouseCurrentStock = $_POST['fromWarehouseCurrentStock'];
    $tbl_serialize_productsIdArray = $_POST['tbl_serialize_productsIdArray'];
    $stockQuantities = $_POST['stockQuantities'];
    $rowCounter = [];
    $sql = "SELECT tbl_warehouse_transfer_requisition_details.id
    FROM tbl_warehouse_transfer_requisition_details
    WHERE  tbl_warehouse_transfer_requisition_details.product_id = ' $product' AND   tbl_warehouse_transfer_requisition_details.from_warehouse = '$wareHouseID' AND tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id = '$requisition_id' AND tbl_warehouse_transfer_requisition_details.deleted = 'No' AND tbl_warehouse_transfer_requisition_details.status = 'Active' ";
    $result = $conn->query($sql);

    while ($row = $result->fetch_array()) {
        array_push($rowCounter, $row['id']);
    }

    if (count($rowCounter) > 0) {
        $sql = "UPDATE `tbl_warehouse_transfer_requisition_details` 
                SET transfer_quentity = transfer_quentity + $transferStock 
                WHERE  tbl_warehouse_transfer_requisition_details.product_id = '$product' AND   tbl_warehouse_transfer_requisition_details.from_warehouse = '$wareHouseID' AND tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id = '$requisition_id' 
                AND tbl_warehouse_transfer_requisition_details.deleted = 'No' AND tbl_warehouse_transfer_requisition_details.status = 'Active' ";
        $result = $conn->query($sql);
    } else {
        $sql = "INSERT into `tbl_warehouse_transfer_requisition_details` ( `tbl_warehouse_transfer_requisition_id`, `product_id`, `request_date`,`from_warehouse_current_stock`, `transfer_quentity`,`from_warehouse`,`to_warehouse`,`tbl_serialize_productsIds`,`stockQuantities`,`status`,`requisition_status`, `deleted`,`created_by`, `created_date`) 
                VALUES ('$requisition_id','$product','$toDay','$fromWarehouseCurrentStock', '$transferStock','$wareHouseID','$transferWareHouse','$tbl_serialize_productsIdArray','$stockQuantities', 'Active','pending','No','$loginID','$toDay') ";

        $result = $conn->query($sql);
        $id = $conn->insert_id;
    }

    $sql = "SELECT tbl_warehouse_transfer_requisition_details.id, tbl_warehouse_transfer_requisition_details.request_date, tbl_warehouse_transfer_requisition_details.transfer_quentity, tbl_products.productName, w1.wareHouseName wr1,w1.id w1_id, w2.wareHouseName wr2, w2.id w2_id
            FROM tbl_warehouse_transfer_requisition_details
            INNER JOIN tbl_products ON tbl_products.id = tbl_warehouse_transfer_requisition_details.product_id
            INNER JOIN tbl_warehouse as w1 ON w1.id = tbl_warehouse_transfer_requisition_details.from_warehouse 
            INNER JOIN tbl_warehouse as w2 ON w2.id = tbl_warehouse_transfer_requisition_details.to_warehouse 
            WHERE tbl_warehouse_transfer_requisition_details.deleted = 'No' AND tbl_warehouse_transfer_requisition_details.status = 'Active'  AND tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id = '$requisition_id'";

    $result = $conn->query($sql);
    $data = [];
    $i = 0;
    while ($row = $result->fetch_array()) {
        $data[$i] = $row;
        $i++;
    }
    echo json_encode([
        'success'       => 'success',
        'id'            => $requisition_id,
        'data'          => $data
    ]);
} else if (isset($_GET['loadRequisitionDetails'])) {

    $requisition_id = $_GET['requisitionId'];
    $sql = "SELECT tbl_warehouse_transfer_requisition_details.id, tbl_warehouse_transfer_requisition_details.request_date, tbl_warehouse_transfer_requisition_details.requisition_status , tbl_warehouse_transfer_requisition_details.matched, tbl_warehouse_transfer_requisition_details.not_mached_qty , tbl_warehouse_transfer_requisition_details.requisition_transfer_by, tbl_warehouse_transfer_requisition_details.requisition_transfer_date, tbl_warehouse_transfer_requisition_details.send_quantity, tbl_warehouse_transfer_requisition_details.receive_by, tbl_warehouse_transfer_requisition_details.receive_date, tbl_warehouse_transfer_requisition_details.receive_quantity,tbl_warehouse_transfer_requisition_details.transfer_quentity , tbl_warehouse_transfer_requisition_details.adjusted_quantity, tbl_products.productName, tbl_products.modelNo, tbl_products.id p_id, w1.wareHouseName wr1, w2.wareHouseName wr2, w1.id w1_id, w2.id w2_id, aw1.wareHouseName aw_1, aw2.wareHouseName aw_2, tbl_warehouse_transfer_requisition.id as requisition_id, tbl_warehouse_transfer_requisition_details.from_warehouse_current_stock
            FROM tbl_warehouse_transfer_requisition_details
            INNER JOIN tbl_warehouse_transfer_requisition ON tbl_warehouse_transfer_requisition.id = tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id AND tbl_warehouse_transfer_requisition.deleted ='No'
            INNER JOIN tbl_products ON tbl_products.id = tbl_warehouse_transfer_requisition_details.product_id
            INNER JOIN tbl_warehouse as w1 ON w1.id = tbl_warehouse_transfer_requisition_details.from_warehouse 
            INNER JOIN tbl_warehouse as w2 ON w2.id = tbl_warehouse_transfer_requisition_details.to_warehouse 
            LEFT JOIN tbl_warehouse as aw1 ON aw1.id = tbl_warehouse_transfer_requisition_details.adjusted_form 
            LEFT JOIN tbl_warehouse as aw2 ON aw2.id = tbl_warehouse_transfer_requisition_details.adjusted_to 
            WHERE tbl_warehouse_transfer_requisition_details.deleted = 'No' AND tbl_warehouse_transfer_requisition_details.status = 'Active'  AND tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id = '$requisition_id'";

    $result = $conn->query($sql);
    $data = array();
    $i = 0;

    while ($row = $result->fetch_array()) {
        $data[$i] = $row;
        $i++;
    }

    echo json_encode([
        'success'       => 'success',
        'id'            => $requisition_id,
        'data'          => $data,
    ]);
} else if (isset($_POST['wtAdjust'])) {

    $requisitionProductId = $_POST['requisitionProductId'];
    $requisitionId = $_POST['requisitionId'];
    $adjusdtQty = $_POST['adjustQty'];
    $products = $_POST['product_id'];
    $wareHouseFrom = $_POST['fromWarehouse'];
    $wareHouseTo = $_POST['toWarehouse'];
    $from_warehouse_current_stock = $_POST['from_warehouse_current_stock'];
    $missedQty = $_POST['missedQty'];
    $missMatchedStatus = $_POST['missMatchedStatus'];
    $remarks = $_POST['remarks'];

    try {
        $conn->begin_transaction();

        if ($missMatchedStatus == 'No') {
            $sql = "SELECT currentStock FROM `tbl_currentStock` where tbl_wareHouseId =  $wareHouseFrom  AND deleted='No' AND tbl_productsId = $products ";
            $result = $conn->query($sql);
            $data = $result->fetch_assoc();
            $availableStock =  $data['currentStock'];
            if ($adjusdtQty <= $availableStock) {

                $sql = "UPDATE `tbl_warehouse_transfer_requisition_details`  
                        SET adjusted_quantity= '$adjusdtQty', adjusted_by ='$loginID', adjusted_date = '$toDay',adjusted_form =   $wareHouseFrom , adjusted_to =  $wareHouseTo , requisition_status = 'adjusted', adjust_remarks = '$remarks', matched = 'Yes'
                        WHERE id='$requisitionProductId' AND deleted='No'";

                if ($conn->query($sql)) {
                    $sql = "INSERT INTO tbl_warehouse_transfer(warehouse_requisition_transfer_product_id, transferDate, tbl_products_id, tbl_current_warehouse_id, current_stock, tbl_transfer_warehouse_id, transfer_stock, entryBy, entryDate) 
                        VALUES ('$requisitionProductId','$toDay','$products','$wareHouseFrom','$availableStock','$wareHouseTo','$adjusdtQty','$loginID','$toDay')";
                    if ($conn->query($sql)) {
                        $sql = "UPDATE tbl_currentStock 
                            SET transferFrom=transferFrom+$adjusdtQty,lastUpdatedDate='$toDay',lastUpdatedBy='$loginID', 
                                currentStock = currentStock - $adjusdtQty 
                            WHERE tbl_wareHouseId='$wareHouseFrom' AND tbl_productsId='$products' AND deleted='No'";

                        if ($conn->query($sql)) {
                            $sql = "UPDATE tbl_currentStock 
                                SET transferTo=transferTo+$adjusdtQty,lastUpdatedDate='$toDay',lastUpdatedBy='$loginID',
                                    currentStock = currentStock + $adjusdtQty 
                                WHERE tbl_wareHouseId='$wareHouseTo' AND tbl_productsId='$products' AND deleted='No'";
                            if ($conn->query($sql)) {
                                if ($conn->affected_rows == 0) {
                                    $sql = "INSERT INTO tbl_currentStock(tbl_productsId, tbl_wareHouseId, currentStock, transferTo, entryBy,entryDate) 
                                        VALUES ('$products', '$wareHouseTo', '$adjusdtQty', '$adjusdtQty', '$loginID','$toDay')";
                                    $conn->query($sql);
                                }
                            }

                            $rowCounter1 = [];
                            $rowCounter2 = [];
                            $sql = "SELECT id  from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId' AND requisition_status NOT IN('cancel','adjusted') and deleted ='No' AND  `status` = 'Active'";
                            $result = $conn->query($sql);

                            while ($row1 = $result->fetch_array()) {
                                array_push($rowCounter1, $row1['id']);
                            }

                            $sql = "SELECT id from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId'  and requisition_status ='completed' and deleted ='No' AND  `status` = 'Active'";
                            $result = $conn->query($sql);

                            while ($row1 = $result->fetch_array()) {
                                array_push($rowCounter2, $row1['id']);
                            }

                            if (count($rowCounter1) == count($rowCounter2)) {
                                $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Complete'
                                        WHERE tbl_warehouse_transfer_requisition.id =  '$requisitionId'  AND `deleted` = 'No' AND  `status` = 'Active'";

                                $result = $conn->query($sql);
                            } else if (count($rowCounter1) > count($rowCounter2)) {
                                $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Incomplete'
                                        WHERE tbl_warehouse_transfer_requisition.id =   '$requisitionId' AND `deleted` = 'No' AND  `status` = 'Active'";

                                $result = $conn->query($sql);
                            }

                            $conn->commit();
                            echo json_encode('Success');
                        } else {
                            $conn->rollBack();
                            echo json_encode('RollBack');
                        }
                    } else {
                        $conn->rollBack();
                        echo json_encode('RollBack');
                    }
                } else {
                    $conn->rollBack();
                    echo json_encode('RollBack');
                }
            } else {
                echo json_encode('not_available');
            }
        } else {
            echo json_encode('not_allow');
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode('RollBack' . $e);
    }
    $conn->close();
} else if (isset($_POST['sendRequisition'])) {

    $requisition_id = $_POST['requisition_id'];
    try {
        $conn->begin_transaction();
        $sql = "UPDATE     `tbl_warehouse_transfer_requisition` 
            SET status= 'Active'
            WHERE id='$requisition_id' AND deleted='No'";

        if ($conn->query($sql)) {
            $conn->commit();
            echo json_encode(['success' => 'success', 'requisition_id' => $requisition_id]);
        } else {
            $conn->rollBack();
            echo json_encode('RollBack');
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode('RollBack' . $e);
    }
    $conn->close();
} else if (isset($_POST['cancleRequisitionProduct'])) {

    $requisitionProduct_id = $_POST['requisitionProductId'];
    $requisitionId = $_POST['requisitionId'];

    try {
        $conn->begin_transaction();
        $sql = "UPDATE     `tbl_warehouse_transfer_requisition_details` 
            SET requisition_status= 'cancel'
            WHERE id='$requisitionProduct_id' AND deleted='No'";

        if ($conn->query($sql)) {

            $rowCounter1 = [];
            $rowCounter2 = [];
            $sql = "SELECT id  from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId' AND requisition_status NOT IN('cancel','adjusted') and deleted ='No' AND  `status` = 'Active'";
            $result = $conn->query($sql);

            while ($row1 = $result->fetch_array()) {
                array_push($rowCounter1, $row1['id']);
            }

            $sql = "SELECT id from tbl_warehouse_transfer_requisition_details where tbl_warehouse_transfer_requisition_id= '$requisitionId'  and requisition_status ='completed' and deleted ='No' AND  `status` = 'Active'";
            $result = $conn->query($sql);

            while ($row1 = $result->fetch_array()) {
                array_push($rowCounter2, $row1['id']);
            }

            if (count($rowCounter1) == count($rowCounter2)) {
                $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Complete'
                        WHERE tbl_warehouse_transfer_requisition.id =  '$requisitionId'  AND `deleted` = 'No' AND  `status` = 'Active'";

                $result = $conn->query($sql);
            } else if (count($rowCounter1) > count($rowCounter2)) {
                $sql = "UPDATE tbl_warehouse_transfer_requisition set  `requisition_status` = 'Incomplete'
                        WHERE tbl_warehouse_transfer_requisition.id =   '$requisitionId' AND `deleted` = 'No' AND  `status` = 'Active'";

                $result = $conn->query($sql);
            }

            $conn->commit();
            echo json_encode(['success' => 'success']);
        } else {
            $conn->rollBack();
            echo json_encode('RollBack');
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode('RollBack' . $e);
    }
    $conn->close();
} else if (isset($_POST['deleteTransferRequisition'])) {

    $requisitionId = $_POST['requisitionId'];
    $rowCounter = [];
    try {
        $conn->begin_transaction();
        $sql = "SELECT id FROM `tbl_warehouse_transfer_requisition_details` WHERE tbl_warehouse_transfer_requisition_id = $requisitionId AND requisition_status IN('transit','completed') AND deleted='No'";
        $result = $conn->query($sql);

        while ($row = $result->fetch_array()) {
            array_push($rowCounter, $row['id']);
        }
        if (count($rowCounter) > 0) {
            echo json_encode(['not_allow' => 'not_allow']);
        } else {

            $sql = "UPDATE   `tbl_warehouse_transfer_requisition` 
            SET deleted= 'Yes'
            WHERE id='$requisitionId' AND deleted='No'";

            if ($conn->query($sql)) {
                $sql = "UPDATE   `tbl_warehouse_transfer_requisition_details` 
                SET deleted= 'Yes'
                WHERE tbl_warehouse_transfer_requisition_id='$requisitionId' AND deleted='No'";
                if ($conn->query($sql)) {
                    $conn->commit();
                    echo json_encode(['success' => 'success']);
                } else {
                    $conn->rollBack();
                    echo json_encode('RollBack');
                }
            } else {
                $conn->rollBack();
                echo json_encode('RollBack');
            }
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode('RollBack' . $e);
    }
    $conn->close();
} else if (isset($_POST['deleteRequisitionProduct'])) {

    $requisitionProduct_id = $_POST['requisitionProductId'];
    try {
        $conn->begin_transaction();
        $sql = "UPDATE     `tbl_warehouse_transfer_requisition_details` 
            SET deleted= 'Yes'
            WHERE id='$requisitionProduct_id' AND deleted='No'";
        $result = $conn->query($sql);
        if ($conn->query($sql)) {
            $conn->commit();
            echo json_encode(['success' => 'success']);
        } else {
            $conn->rollBack();
            echo json_encode('RollBack');
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode('RollBack' . $e);
    }
    $conn->close();
} else {

    //$type = $_GET['type'];
    $status = isset($_GET['type']) ? $_GET['type'] : 'Active';
    if ($status == 'Inactive') {
        $query_part = "AND tbl_warehouse_transfer_requisition.created_by = $loginID";
    } else {
        $query_part = "";
    }

    $sql = "SELECT tbl_warehouse_transfer_requisition.id, tbl_warehouse_transfer_requisition.requisition_date, tbl_warehouse_transfer_requisition.requisition_no, tbl_warehouse.wareHouseName as receive_warehouse, tbl_warehouse_transfer_requisition.status, tbl_warehouse_transfer_requisition.requisition_status
            FROM tbl_warehouse_transfer_requisition
            LEFT JOiN tbl_warehouse on tbl_warehouse.id = tbl_warehouse_transfer_requisition.receive_warehouse
            WHERE tbl_warehouse_transfer_requisition.deleted='No' AND tbl_warehouse_transfer_requisition.status = '$status' $query_part
            order by tbl_warehouse_transfer_requisition.id DESC";

    $result = $conn->query($sql);
    $i = 1;
    $output = array('data' => array());
    while ($row = $result->fetch_array()) {
        $id = $row['id'];
        $date =  $row['requisition_date'];
        $code =  $row['requisition_no'];
        $missMatched ='';
        $sql = "SELECT tbl_warehouse_transfer_requisition_details.id, tbl_warehouse_transfer_requisition_details.matched
                FROM tbl_warehouse_transfer_requisition_details
                WHERE tbl_warehouse_transfer_requisition_details.deleted='No' AND tbl_warehouse_transfer_requisition_details.matched='No' AND tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id = $id 
                order by tbl_warehouse_transfer_requisition_details.id DESC";
                $data = $conn->query($sql);
                if($data){
                    if ($data->num_rows > 0) { 
                        $missMatched =  $data->num_rows.' Miss Matched';
                    }
                   
                }
                
        $button = '';

        $button .= '	<div class="btn-group">
						<button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
						<i class="fa fa-gear tiny-icon"></i> <span class="caret"></span></button>
						<ul class="dropdown-menu dropdown-menu-right" style="border: 1px solid gray;" role="menu">';
        if ($status == "Inactive") {
            $button .=  '<li><a href="wareHouseTransferactionRequestAdd.php?id=' . $id . '"><i class="fa fa-edit tiny-icon"></i>Complete</a></li>';
        }
        if ($status == "Active") {
            $button .=  '<li><a href="#" onclick="createPdf(' . $id . ')"><i class="fa fa-print tiny-icon"></i>View Details</a></li>
                                        <li><a href="#" onclick="viewDetails(' . $id . ',\'' . $code . '\')"><i class="fa fa-print tiny-icon"></i>View Status</a></li>';
        }
        
        $button .= '<li><a href="#" onclick="deleteTransferRequisition(' . $id . ')"><i class="fa fa-trash tiny-icon"></i>Delete</a></li>';

        $button .= '</ul></div>';
        $output['data'][] = array(
            $i++,
            $row['requisition_date'],
            $row['requisition_no'],
            $row['receive_warehouse'],
            '<b>'.$row['requisition_status'] .'</b><br><span class="text-danger">'.  $missMatched.'</span>',
            $button
        );
    }
    echo json_encode($output);
}
