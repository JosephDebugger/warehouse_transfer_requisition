<?php
$conPrefix = '';
include 'includes/session.php';
include 'includes/header.php';

?>
<style>
    .disabled-adv-btn {
        pointer-events: none;
    }

    fieldset.scheduler-border {
        border: 1px groove #ddd !important;
        padding: 0 1.4em 1.4em 1.4em !important;
        margin: 0 0 1.5em 0 !important;
        -webkit-box-shadow: 0px 0px 0px 0px #000;
        box-shadow: 0px 0px 0px 0px #000;
    }

    legend.scheduler-border {
        font-size: 1.2em !important;
        font-weight: bold !important;
        text-align: left !important;
        width: auto;
        padding: 0 10px;
        border-bottom: none;
    }
</style>
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT  requisition_no, receive_warehouse, requisition_date, transfer_by , tbl_warehouse.wareHouseName FROM `tbl_warehouse_transfer_requisition`
            JOIN tbl_warehouse on tbl_warehouse_transfer_requisition.receive_warehouse = tbl_warehouse.id
     WHERE tbl_warehouse_transfer_requisition.id = $id";
    $result = $conn->query($sql);

    if ($prow = $result->fetch_assoc()) {
        $requisition_code = $prow['requisition_no'];
        $requisition_date = $prow['requisition_date'];
        $receive_warehouse_id = $prow['receive_warehouse'];
        $receive_warehouse_name = $prow['wareHouseName'];
        $transfer_by = $prow['transfer_by'];
        $warehouseDesable = 'disabled';
    }
} else {
    $requisition_date = date('Y-m-d');
    $requisition_code = '';
    $transfer_by = '';
    $receive_warehouse = '';
    $receive_warehouse_name = '';
}
?>

<body class="hold-transition skin-blue sidebar-mini">
    <link rel="stylesheet" href="dist/css/select2.min.css" />
    <div class="wrapper">

        <?php include 'includes/navbar.php'; ?>
        <?php include 'includes/menubar.php'; ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Transfer Request
                </h1>
                <ol class="breadcrumb">
                    <li><a href="manage-view.php"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">
                        Transfer Request
                    </li>
                </ol>
            </section>
            <!-- Main content -->
            <section class="content">
                <link rel="stylesheet" href="css/buttons.dataTables.min.css" />
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="col-xs-6"></div>
                                <div class="col-xs-6">
                                    <div id='divMsg' class='alert alert-success alert-dismissible successMessage'></div>
                                    <div id='divErrorMsg' class='alert alert-danger alert-dismissible errorMessage'></div>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="col-md-12">
                                    <div class="col-md-10 row">

                                        <div class="col-md-6 reg-code <?= $status = isset($_GET['id']) ? '' : 'd-none'; ?>">
                                            <label class="" for="requisition_code">Requisition Code</label>

                                            <input class="form-control col-md-6" type="text" name="requisition_code" id="requisition_code" value=" <?= $requisition_code ?>" disabled>

                                        </div>

                                        <div class="col-md-6">
                                            <label class="" for="requisition_date">Requisition Date</label>
                                            <div class="">
                                                <input class="form-control col-md-12" type="Date" name="requisition_date" id="requisition_date" value="<?= $requisition_date ?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="">To Warehouse</label>
                                            <select class="form-control mb-5" id="transferWareHouse" style="width:100%;" <?= $warehouseDesable ?>>


                                                <?php
                                                if (isset($_GET['id'])) {
                                                    echo "<option value='" . $receive_warehouse_id . "' Selected>" . $receive_warehouse_name . " </option>";
                                                } else {

                                                    $sql = "SELECT wareHouseName, id
                                                    FROM `tbl_warehouse`         
                                                    WHERE tbl_warehouse.deleted='No' ORDER BY `id` DESC";
                                                    $query = $conn->query($sql);

                                                    while ($row = $query->fetch_array()) {
                                                        echo "<option value='" . $row['id'] . "' >" . $row['wareHouseName'] . " </option>";
                                                    }
                                                }
                                                ?>
                                            </select>
                                            <select class="form-control" name="transferWareHouseStock" id="transferWareHouseStock" style="display:none;">
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="transferBy" class="">Transfer By</label>
                                            <select class="form-control" name="transferBy" id="transferBy">
                                                <option value="" selected>~~ Select ~~</option>
                                                <?php
                                                $sql = "SELECT fname, id
                                                                FROM `tbl_users`         
                                                                WHERE tbl_users.deleted='No' ORDER BY `id` DESC";
                                                $query = $conn->query($sql);
                                                while ($prow = $query->fetch_array()) {
                                                    if ($transfer_by == $prow['id']) {
                                                        echo "<option value='" . $prow['id'] . "' Selected>" . $prow['fname'] . " </option>";
                                                    } else {
                                                        echo "<option value='" . $prow['id'] . "'>" . $prow['fname'] . " </option>";
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="col-md-6 btn_create_div mt-10">
                                            <button type="submit" class="btn btn-primary form-control btn-flat create-requisition-btn" onclick="createTransferRequisition()" name="btn_create" id="btn_create"><i class="fa fa-save"></i> Create </button>
                                        </div>

                                        <div class="col-md-6 float-right" style="right: 0; margin-right: 0;">
                                            <a href="wareHouseTransferRequest-view.php" class="btn btn-secondary float-right"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box">
                            <div class="box-body">
                                <div class="col-md-8 input-group">
                                    <label for="products">
                                        <h4><b>Select Product</b></h4>
                                    </label>
                                    <div class="input-group">
                                        <select class="form-control col-md-12 " name="products" id="products" disabled>
                                            <option value="" selected>~~ Select Product ~~</option>
                                            <?php
                                            $sql = "SELECT tbl_products.id,tbl_products.productName,tbl_products.productCode,tbl_brands.brandName ,tbl_products.productDescriptions
                                                        FROM `tbl_products` 
                                                        LEFT OUTER JOIN tbl_brands ON tbl_brands.id=tbl_products.tbl_brandsId
                                                        WHERE tbl_products.status='Active' ORDER BY `id`  DESC";
                                            $query = $conn->query($sql);
                                            while ($prow = $query->fetch_assoc()) {
                                                echo "<option value='" . $prow['id'] . "'>" . $prow['productName'] .  "-" . $prow['productDescriptions'] . " - (" . $prow['brandName'] . ") </option>";
                                            }
                                            ?>
                                        </select>
                                        <a href="#" onclick="advanceSearch('wareHouseTransfer')" class="input-group-addon adv-btn disabled-adv-btn" data-sales-type="wareHouseTransfer" style="background-color:#171991;color:#fff;border-radius: 0px 8px 8px 0px;box-shadow: -5px 0px 0px 0px #171991;border: 1px solid #171991;" disabled><i class="fa fa-search" style="font-size: 18px;"></i></a>
                                    </div>
                                </div>
                                <br>
                                <form class="form-horizontal" id="form_transfer_requisition" method="POST" action="#">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input class="form-control " type="hidden" name="requisition_id" id="requisition_id" value="">
                                            <fieldset class="scheduler-border" visible="true" id="fromSet" disabled>
                                                <legend class="scheduler-border">From Warehouse</legend>
                                                <div class="col-md-12 input-group">
                                                    <label for="">From Warehouse</label>
                                                    <select class="form-control mb-5" id="wareHouseID" style="width:100%;" disabled>

                                                    </select>
                                                    <select class="form-control" name="wareHouseStock" id="wareHouseStock" style="display:none;">
                                                    </select>
                                                </div>
                                                <div class="col-md-12 input-group">
                                                    <label for="">Current Stock</label>
                                                    <input class="form-control" type="text" name="currentStock" id="currentStock" placeholder="Current Stock" readonly>
                                                </div>
                                                <div class="col-md-12 input-group">
                                                    <label for="">Transfer Stock</label>
                                                    <input class="form-control" type="number" name="transferStock" id="transferStock" placeholder="Transfer Quantity">
                                                    <span class="input-group-btn">
                                                        <button id="ShowSerializeBtn" class="btn btn-primary hidden" type="button" onclick="showSerializTable()"><i class="fa fa-eye"></i></button>
                                                    </span>
                                                </div>
                                                <div class="col-md-12 input-group">
                                                    <label for="">Remaining Stock</label>
                                                    <input class="form-control" type="text" name="remainingStock" id="remainingStock" placeholder="Remaining Stock" readonly>
                                                </div>
                                            </fieldset>
                                        </div>
                                        <div class="col-md-6">
                                            <fieldset class="scheduler-border" id="toSet" disabled>
                                                <legend class="scheduler-border">To Warehouse</legend>
                                                <div class="col-md-12">

                                                    <label for="">To Warehouse</label>
                                                    <input type="text" class="form-control" name="transferWareHouseInfo" id="transferWareHouseInfo" placeholder="To Warehouse" readonly>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="">Current Stock</label>
                                                    <input type="text" class="form-control" name="transferWareHouseCurrentStock" id="transferWareHouseCurrentStock" placeholder="Current Stock" readonly>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="">After Transfer Stock</label>
                                                    <input type="text" class="form-control" name="afterTransferStock" id="afterTransferStock" placeholder="After Transfer quantity" readonly>
                                                </div>
                                            </fieldset>
                                            <div class="col-md-6">
                                                <button type="submit" class="btn btn-primary form-control form btn-flat" name="btn_saveRequisition" id="btn_save"><i class="fa fa-save"></i> Save </button>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>

                            <div class="box-header with-border">
                                <div class="col-xs-6">

                                </div>
                            </div>
                            <div class="box-body table-responsive">
                                <input type="hidden" id="" name="" value="" />
                                <table id="manageRequisitionTable" class="table table-bordered" width="100%">
                                    <thead style="background-color:#ede7e6">
                                        <th>SN#</th>
                                        <th>Product</th>
                                        <th>Transfer Quantity</th>
                                        <th>From WareHouse</th>
                                        <th>To WareHouse</th>
                                        <th>Transfer Quantity</th>
                                        <th style="width:8%;">Action</th>
                                    </thead>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div>

        <?php include 'includes/footer.php';
        include 'includes/productAdvanceSearch-modal.php';
        include 'includes/saleSerializeProductReturn-modal.php';
        ?>
    </div>
    <?php include 'includes/scripts.php'; ?>
    <script src="dist/js/select2.min.js"></script>
    <script src="includes/js/manageWareHouseTransferRequest.js"></script>

</body>

</html>