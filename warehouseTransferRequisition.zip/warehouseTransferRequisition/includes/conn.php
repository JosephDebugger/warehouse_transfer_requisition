<?php
	 $conn = new mysqli('localhost', 'root', '','luwqeb45_bd_supplier');

	if ($conn->connect_error) {
	    //die("Connection failed: " . $conn->connect_error);
	    die("This site is under construction.");
	}
?>