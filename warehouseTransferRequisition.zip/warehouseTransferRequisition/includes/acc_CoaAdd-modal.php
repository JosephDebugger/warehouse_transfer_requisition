<!-- modal -->
<div class="modal fade" id="modal">
    <div class="modal-dialog" style="width:35%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><b>Add Coa</b></h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="col-form-label">Parent</label>
                    <select type="text" class="form-control" id="parent_id" name="parent_id">
                        <option style="font-weight: bold;" value="0">No Parent</option>
                        <?php
                        $sql = "SELECT * FROM `tbl_acc_coas` WHERE deleted = 'No' ORDER BY `id` DESC";
                        $coas = $conn->query($sql);
                        $status = '';

                        foreach ($coas as $coa) {
                            if ($coa['parent_id'] == '0' && $coa['unused'] == 'No') {
                                $status = '';
                            } elseif ($coa['parent_id'] !== '0' && $coa['unused'] == 'No') {
                                $status = '..';
                            } else {
                                $status = '....';
                            }
                            echo '<option value="' . $coa['id'] . '">' . $status . ' ' . $coa['name'] . ' - ' . $coa['code'] . '</option>';
                        }
                        ?>
                    </select>
                    <span class="text-danger" id="parent_idError"></span>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Name">
                    <span class="text-danger" id="nameError"></span>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" placeholder="Slug" readonly>
                    <span class="text-danger" id="slugError"></span>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Code</label>
                    <input type="text" class="form-control" id="code" name="code" placeholder="Code">
                    <span class="text-danger" id="codeError"></span>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary mr-auto" data-dismiss="modal">x
                    Close</button>
                <button class="btn  btn-primary" onclick="saveCoa()"><i class="fa fa-save"></i>
                    Save</button>
            </div>
        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- modal -->
<div class="modal fade" id="editModal">
    <div class="modal-dialog" style="width:35%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><b>Edit</b></h4>
            </div>

            <div class="modal-body">
                <input type="hidden" id="editId">

                <div class="form-group">
                    <label class="col-form-label">Parent</label>
                    <select type="text" class="form-control" id="editParent_id" name="editParent_id">
                        <option style="font-weight: bold;" value="0">No Parent</option>
                        <?php
                        $sql = "SELECT * FROM `tbl_acc_coas` WHERE deleted = 'No' ORDER BY `id` DESC";
                        $coas = $conn->query($sql);
                        $status = '';

                        foreach ($coas as $coa) {
                            if ($coa['parent_id'] == '0' && $coa['unused'] == 'No') {
                                $status = '';
                            } elseif ($coa['parent_id'] !== '0' && $coa['unused'] == 'No') {
                                $status = '..';
                            } else {
                                $status = '....';
                            }
                            echo '<option value="' . $coa['id'] . '">' . $status . ' ' . $coa['name'] . ' - ' . $coa['code'] . '</option>';
                        }
                        ?>
                    </select>
                    <span class="text-danger" id="editParent_idError"></span>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Status</label>
                    <select type="text" class="form-control" id="editStatus" name="editStatus">
                        <option value="" selected disabled>Select Status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                    <span class="text-danger" id="editStatusError"></span>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Name</label>
                    <input type="text" class="form-control" id="editName" name="editName" placeholder="Name" value="">
                    <span class="text-danger" id="editNameError"></span>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Slug</label>
                    <input type="text" class="form-control" id="editSlug" name="editSlug" placeholder="Slug" readonly>
                    <span class="text-danger" id="editSlugError"></span>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Code</label>
                    <input type="text" class="form-control" id="editCode" name="editCode" placeholder="Code">
                    <span class="text-danger" id="editCodeError"></span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary mr-auto" data-dismiss="modal">x
                    Close</button>
                <button class="btn  btn-primary" onclick="updateCoa()"><i class="fa fa-save"></i>
                    Save</button>
            </div>
        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->