<!-- WareHouse Transfer-->
<div class="modal fade" id="warehouseTransferRequisition">
    <div class="modal-dialog" style="width: 60%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><b> WareHouse Transfer </b></h4>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <h5 class="req_code">
                    </h5>
                </div>
                <table class="table" id="requisitions">

                </table>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="adjustModal">
    <div class="modal-dialog" style="width: 40%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><b> WareHouse Transfer Adjust</b></h4>
            </div>
            <div class="modal-body">

           
                <div class="col-md-12 form-group">
                <section>
                    <div style="background-color: #ddd; padding: 12px;">
                        <p>
                          
                          Note:

                        </p>
                        <p id="note">This is Note Block.</p>
                    </div>
                </section>
                    <div class="col-md-3">
                        <label for="status">Status</label>
                        <div id="status"></div>
                    </div>
                    <div class="col-md-3">
                        <label for="">Transfer Qty</label>
                        <div id="transferedQty"></div>
                    </div>
                    <div class="col-md-3">
                        <label for="">Received Qty</label>
                        <div id="receivedQty"></div>
                    </div>
                    <div class="col-md-3">
                        <label for="">Missed Qty</label>
                        <div id="missedQty"></div>
                    </div>
                    
                    <div class="col-md-12">
                        <hr>
                    </div>

                    <div class="col-md-6">
                        <label for="transfer_fromTo">Transfer from</label>
                        <select name="transfer_fromTo" id="transfer_fromTo" class="form-control">
                            <option value="">Select from to</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <input type="hidden" id="requisitionProductId">
                        <input type="hidden" id="requisitionId">
                        <input type="hidden" id="missMatchedStatus">
                        <input type="hidden" id="product_id">
                        <input type="hidden" id="w1_id">
                        <input type="hidden" id="w2_id">
                        <input type="hidden" id="from_warehouse_current_stock">
                        <label for="">Adjust Quantity</label>
                        <input type="number" class="form-control" id="adjustQuantity">
                        <span class="text-danger" id="adjustedQty_error"></span>
                    </div>
                    <div class="col-md-12">
                        <label for="remarks">Remarks</label>
                        <textarea name="remarks" id="remarks" class="form-control" rows="6"></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                    <button type="submit" class="btn btn-primary btn-flat" name="btn_adjust" id="btn_adjust" onclick="wtAdjust()"><i class="fa fa-save"></i> Adjust </button>
                </div>


            </div>
        </div>
    </div>
</div>