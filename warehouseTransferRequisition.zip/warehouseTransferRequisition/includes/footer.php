<footer class="main-footer">
    <div class="pull-right hidden-xs">
      Copyright &copy; 2022 <b>All rights reserved</b>
    </div> 
    
    <img src="icons/atDuronto.png" style="height: 38px;" />
    <strong><a href="" target="_blank"><b style="font-variant: small-caps;">AliTechnology</b></a></strong>
</footer>