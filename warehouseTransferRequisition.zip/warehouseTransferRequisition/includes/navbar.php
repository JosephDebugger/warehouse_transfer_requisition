<style>

</style>

<header class="main-header">
  <!-- Logo -->
  <?php
  include 'timezone.php';
  $today = date('Y-m-d');

  if ($_SESSION['userType'] != 'SALES EXECUTIVE' && strtolower($_SESSION['userType']) != "shop executive") {
    echo '<a href="user-home.php" class="logo">';
  } else {
    echo '<a href="home.php" class="logo">';
  }
  $sqlR = "SELECT COUNT(tbl_discount_offer.id) AS totalRemainder
            FROM `tbl_discount_offer` 
            WHERE REPLACE(tbl_discount_offer.remainder_date,'0000-00-00','2099-01-01') <= '$today' AND tbl_discount_offer.date_to >= '$today' AND tbl_discount_offer.deleted='No' AND tbl_discount_offer.status='Active' ";

  $resultR = $conn->query($sqlR);
  $totalRemainder = 0;
  while ($row = $resultR->fetch_assoc()) {
    $totalRemainder = $row['totalRemainder'];
  }
  ?>
  <!-- mini logo for sidebar mini 50x50 pixels -->
  <span class="logo-mini"><b>BD</b>S</span>

  <span class="logo-lg"><img src="icons/bd12-small.png" style="width: 50px;" /><b>BD SUPPLIERS</b></span>
  </a>
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a>

    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">

        <?php
        $total = [];
        $sql = "SELECT tbl_warehouse_transfer_requisition_details.id ,tbl_warehouse_transfer_requisition_details.requisition_status, tbl_warehouse_transfer_requisition_details.matched, tbl_warehouse_transfer_requisition_details.not_mached_qty, tbl_warehouse_transfer_requisition_details.request_date, tbl_warehouse_transfer_requisition.requisition_no
        FROM `tbl_warehouse_transfer_requisition_details`   
        join tbl_warehouse_transfer_requisition  on tbl_warehouse_transfer_requisition_details.tbl_warehouse_transfer_requisition_id = tbl_warehouse_transfer_requisition.id
        WHERE tbl_warehouse_transfer_requisition_details.deleted='No' AND tbl_warehouse_transfer_requisition_details.requisition_status = 'completed' AND tbl_warehouse_transfer_requisition_details.matched = 'No' AND tbl_warehouse_transfer_requisition_details.status='Active' ";

        $result = $conn->query($sql);

        while ($row = $result->fetch_array()) {
          array_push($total, $row['id']);
        }
        if (count($total) == 0) {
          $total = '';
        }
        ?>
        <li class="dropdown" style="border-left: 1px solid white;border-right: 1px solid white;">
          <a class="dropdown-toggle" data-toggle="dropdown"> Miss Matched <i class="fa fa-bell-o"></i> <span id="" style="color: red;font-weight: 800;"><?= count($total) ?> </span></a>
          <ul class="dropdown-menu" id="" style="height: 400px;width: 320px;overflow-x: scroll;">
            <?php
            $result = $conn->query($sql);
            while ($row = $result->fetch_array()) {
              if ($row['not_mached_qty'] < 0) {
                $msg = 'Miss matched, ' . abs($row['not_mached_qty']) . ' more quantity received';
              } else {
                $msg = 'Miss matched, ' . abs($row['not_mached_qty']) . ' less quantity received';
              }
              echo "<li class='list-group-itemNotice'><a href='wareHouseTransferRequest-view.php'><b>Req No." . $row['requisition_no'] . " - Date: " . $row['request_date'] . "</b><br><small>" . $msg . "</small></a></li>";
            }
            ?>
          </ul>
        </li>

        <li class="dropdown" style="border-left: 1px solid white;border-right: 1px solid white;">
          <a class="dropdown-toggle" data-toggle="dropdown"> Cheque <?php echo  $nextDate; ?> <i class="fa fa-bell-o"></i> <span id="UnReadNotify" style="color: red;font-weight: 800;"> </span></a>
          <ul class="dropdown-menu list-group-flush" id="notification" style="height: 400px;width: 320px;overflow-x: scroll;">
          </ul>
        </li>

        <li class="dropdown user user-menu">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <img src="<?php echo (!empty($user['images'])) ? 'images/' . $user['images'] : 'images/profile.jpg'; ?>" class="user-image" alt="User Image">
            <span class="hidden-xs"><?php echo $user['fname'] . ' ' . $user['lname']; ?></span>
          </a>
          <ul class="dropdown-menu">
            <!-- User image -->
            <li class="user-header">
              <img id="profileImageIcon" src="<?php echo (!empty($user['images'])) ? 'images/' . $user['images'] : 'images/profile.jpg'; ?>" class="img-circle" alt="User Image">

              <p>
                <?php echo $user['fname'] . ' ' . $user['lname']; ?>
                <small>Member since <?php echo date('M. Y', strtotime($user['createdDate'])); ?></small>
              </p>
            </li>
            <li class="user-footer">
              <div class="pull-left">
                <a href="#profile" data-toggle="modal" class="btn btn-default btn-flat" id="admin_profile">Change Password</a>
              </div>
              <div class="pull-right">
                <a href="user/logout.php" class="btn btn-default btn-flat">Sign out</a>
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>
</header>
<?php
include 'includes/profile_modal.php';
include 'includes/adminResetPassword-modal.php';
?>