<?php
$conPrefix = '';
include 'includes/session.php';
include 'includes/header.php';
?>
<style>
  .badge-error {
    background-color: #b94a48;
  }

  .badge-error:hover {
    background-color: #953b39;
  }

  .badge-warning {
    background-color: #f89406;
  }

  .badge-warning:hover {
    background-color: #c67605;
  }

  .badge-danger {
    background-color: #bb2124;
  }


  .badge-primary {
    background-color: #0275d8;
  }

  .badge-primary:hover {
    background-color: #0275d8;
  }

  .badge-success {
    background-color: #468847;
  }

  .badge-success:hover {
    background-color: #356635;
  }

  .badge-info {
    background-color: #3a87ad;
  }

  .badge-info:hover {
    background-color: #2d6987;
  }

  .badge-inverse {
    background-color: #333333;
  }

  .badge-inverse:hover {
    background-color: #1a1a1a;
  }
</style>

<body class="hold-transition skin-blue sidebar-mini">
  <link rel="stylesheet" href="dist/css/select2.min.css" />
  <div class="wrapper">

    <?php include 'includes/navbar.php'; ?>
    <?php include 'includes/menubar.php'; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Warehouse Transfer
        </h1>
        <ol class="breadcrumb">
          <li><a href="user-home.php"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active">Warehouse Transfer Request</li>
        </ol>

      </section>
      <!-- Main content -->
      <section class="content">
        <link rel="stylesheet" href="css/buttons.dataTables.min.css" />
        <div class="row">
          <div class="col-xs-12">
            <div class="box">
              <div class="box-header with-border">
                <div class="col-xs-6">
                  <a href="/bdsupplier/wareHouseTransferactionRequestAdd.php" class="btn btn-primary btn-sm btn-flat addBtn"><i class="fa fa-plus"></i> Warehouse Transfer [requisition] </a>
                  <?php
                  $rowCounter = [];
                  $sql = "SELECT tbl_warehouse_transfer_requisition.id as r_id, tbl_warehouse_transfer_requisition.requisition_date, tbl_warehouse_transfer_requisition.requisition_no
                          FROM tbl_warehouse_transfer_requisition
                          WHERE tbl_warehouse_transfer_requisition.deleted='No' AND tbl_warehouse_transfer_requisition.status='Inactive' 
                          order by tbl_warehouse_transfer_requisition.id DESC";
                  $result = $conn->query($sql);

                  while ($row1 = $result->fetch_array()) {
                    array_push($rowCounter, $row1['r_id']);
                  }

                  if (count($rowCounter) > 0) {
                    $status = "Inactive";
                    $count = count($rowCounter);
                    $pendingBtg = '<a  class="btn btn-primary btn-sm btn-flat pendingBtn d-none" onclick="reloadTable(\'Inactive\');">Inactivated<sup> ' . $count . '</sup> </a>';
                    echo  $pendingBtg;
                  } else {
                    $pendingBtg = '';
                    echo  $pendingBtg;
                  }

                  ?>
                  <!-- <button class="btn btn-primary btn-sm btn-flat float-right backBtn d-none" onclick="reloadTable('All');"> All </button> -->
                </div>
                <div class="col-xs-6">
                  <div id='divMsg' class='alert alert-success alert-dismissible successMessage'></div>
                  <div id='divErrorMsg' class='alert alert-danger alert-dismissible errorMessage'></div>
                </div>
              </div>
              <div class="box-body table-responsive">
                <table id="manageWareHouseTransferTable" class="table table-responsive table-bordered" style="width:100%">
                  <thead>
                    <th style="width:5%;">#SN</th>
                    <th>Requisition Date</th>
                    <th>Requisition Code</th>
                    <th>Destination Warehouse</th>
                    <th>Status</th>
                    <th style="width:8%;">Action</th>
                  </thead>
                  <tbody></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
    <?php include 'includes/footer.php'; ?>
  </div>
  <?php
  include 'includes/scripts.php';
  include 'includes/wareHouseTransferReview-modal.php';
  include 'includes/productAdvanceSearch-modal.php';

  ?>
  <script src="dist/js/select2.min.js"></script>
  <script src="includes/js/manageWareHouseTransferRequest.js"></script>
</body>

</html>